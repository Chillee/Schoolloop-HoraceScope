Just drag the .crx file into chrome to install.

However, the .crx file is not always up to date. To install the latest version, follow these steps.

1. Download the files in the chrome extension directory to a folder.
2. Go to chrome://extensions
3. Check developer mode.
4. Choose to load unpacked extensions
5. Choose the folder you downloaded the files into.
6. Navigate to one of your progress reports.